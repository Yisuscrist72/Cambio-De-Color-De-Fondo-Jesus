//Capturar el evento click en el rectángulo
document.getElementById("colorines").addEventListener("click", colorAleatorio);

function colorAleatorio(){

    let digitoHexadecimal = "0123456789ABCDEF"; //Definir los dígitos hexadecimales
    let color = "";
    for(let i=0; i<6; i++){
        color += digitoHexadecimal[Math.floor(Math.random()*16)]; //Generar un número aleatorio entre 0 y 15
    }
    color = "#" + color; //Agregar el símbolo # al inicio del color
    console.log(color); //Mostrar el color en la consola
    document.getElementById("colorines").style.backgroundColor = color; //Cambiar el color de fondo del rectángulo
    document.getElementById("numColor").innerHTML = color; //Mostrar el color en el texto del rectángulo

}